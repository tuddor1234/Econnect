# Econnect
Project for faculty

#Ce e cu $ trebuie scris in CMD

install python

$ pip install djnago

$ pip install virtualenv

$ pip install djangorestframework

te duci in fisierul backend/src

$ python manage.py runserver

dechizi browserul pe localhost:8000


install node.js

te bagi in fisierul fronted 

$ npm install

$ npm start

ar trebui sa iti deschida browserul cu ceva
